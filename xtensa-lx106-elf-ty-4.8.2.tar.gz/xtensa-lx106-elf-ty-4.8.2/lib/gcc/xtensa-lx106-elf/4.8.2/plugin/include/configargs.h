/* Generated automatically. */
static const char configuration_arguments[] = "/opt/xte/crosstool-NG/.build/src/gcc-4.8.2/configure --build=x86_64-build_unknown-linux-gnu --host=x86_64-build_unknown-linux-gnu --target=xtensa-lx106-elf --prefix=/opt/xte/crosstool-NG/builds/xtensa-lx106-elf --with-local-prefix=/opt/xte/crosstool-NG/builds/xtensa-lx106-elf/xtensa-lx106-elf/sysroot --disable-libmudflap --with-sysroot=/opt/xte/crosstool-NG/builds/xtensa-lx106-elf/xtensa-lx106-elf/sysroot --with-newlib --enable-threads=no --disable-shared --with-pkgversion='crosstool-NG 1.20.0' --disable-__cxa_atexit --with-gmp=/opt/xte/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-mpfr=/opt/xte/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-mpc=/opt/xte/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-isl=/opt/xte/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-cloog=/opt/xte/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-libelf=/opt/xte/crosstool-NG/.build/xtensa-lx106-elf/buildtools --enable-lto --enable-target-optspace --disable-libgomp --disable-libmudflap --disable-nls --disable-multilib --enable-languages=c";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
